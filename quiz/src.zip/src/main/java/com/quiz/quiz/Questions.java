package com.quiz.quiz;

public class Questions {
    private String questionsText ;
    private Answer [] answers;


    public Questions(String questionsText, Answer[] answers) {
        this.questionsText = questionsText;
        this.answers = answers;
    }



    public void setQuestions(String questions) {
        this.questionsText = questions;
    }

    public void setAnswers(Answer[] answers) {
        this.answers = answers;
    }

    public String getQuestionsText() {
        return questionsText;
    }

    public Answer[] getAnswers() {
        return answers;
    }
}
