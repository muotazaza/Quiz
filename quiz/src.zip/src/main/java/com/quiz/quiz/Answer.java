package com.quiz.quiz;

public class Answer {
    public String Id;
    public String answerString;
    public  String SubmittedBy;

    public Answer(String id, String answerString, String submittedBy) {
        Id = id;
        this.answerString = answerString;
        SubmittedBy = submittedBy;
    }

    public void setId(String id) {
        Id = id;
    }

    public void setAnswer(String answer) {
        this.answerString = answer;
    }

    public void setSubmittedBy(String submittedBy) {
        SubmittedBy = submittedBy;
    }

    @Override
    public String toString() {
        return "(by" + SubmittedBy + ") " + answerString;
    }
}
